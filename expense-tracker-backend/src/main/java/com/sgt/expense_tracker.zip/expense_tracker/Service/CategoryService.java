package com.sgt.expense_tracker.Service;

import com.sgt.expense_tracker.Exceptions.EmailNotRegisteredException;
import com.sgt.expense_tracker.Model.Category;
import com.sgt.expense_tracker.Repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    CategoryRepository categoryRepository;
    public boolean checkIfUserIdExists(int id){
        return categoryRepository.checkIfUserIdExists(id);
    }
    public void addCategory(Category category) throws EmailNotRegisteredException{
        int user_id=category.getUser_id();
        String name= category.getName();
        String description= category.getDescription();
        String icon_url= category.getIcon_url();
        String transaction_type=category.getTransaction_type();

        categoryRepository.addCategory(user_id,name,description,icon_url,transaction_type);
    }
    public List<Category> getCategories(int user_id){
          return  categoryRepository.getCategories(user_id);
    }
    public List<Category> getCategoryById(int id){
        return  categoryRepository.getCategoryById(id);
    }
    public void editCategory(int id,Category category){
        String name=category.getName();
        String description=category.getDescription();
        String icon_url=category.getIcon_url();
        String transaction_type=category.getTransaction_type();
        categoryRepository.editCategory(id,name,description,icon_url,transaction_type);
    }
    public void deleteCategory(int id){
        categoryRepository.deleteCategory(id);
    }
}
